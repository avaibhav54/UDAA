#include <iostream>

using namespace std;

int main() { 
    int a=0,b=0,c=0;
    cin>>a;
    cin>>b;
    c=a+b;
    cout<<c;
    return 0;
}
